const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const DATA_DIR = path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'messages.json');
app.use(express.json());
app.use(express.static(__dirname)); // serve your src files

// ensure data dir/file exists
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, '[]', 'utf8');

app.post('/api/messages', (req, res) => {
  const { name, email, message } = req.body || {};
  if (!name || !email || !message) return res.status(400).json({ error: 'missing fields' });
  const list = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  list.push({ id: Date.now(), name, email, message, created_at: new Date().toISOString() });
  fs.writeFileSync(DATA_FILE, JSON.stringify(list, null, 2), 'utf8');
  res.json({ ok: true });
});

const PORT = 3000;
app.listen(PORT, () => console.log(`Mock server running http://localhost:${PORT}`));